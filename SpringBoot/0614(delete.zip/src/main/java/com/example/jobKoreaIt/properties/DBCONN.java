package com.example.jobKoreaIt.properties;

public class DBCONN {

    public static final String URL = "jdbc:mysql://localhost:3306/KoreaJob";
    public static final String ID = "root";
    public static final String PW = "1234";

}


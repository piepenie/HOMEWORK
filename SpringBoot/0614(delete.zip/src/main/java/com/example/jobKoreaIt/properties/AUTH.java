package com.example.jobKoreaIt.properties;

public class AUTH {


}

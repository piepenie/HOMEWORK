package com.example.jobKoreaIt.properties;

public class UPLOADPATH {

    public static String UPLOADPATH="c:\\upload";

}

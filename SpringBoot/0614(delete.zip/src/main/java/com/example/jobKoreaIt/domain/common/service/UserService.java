package com.example.jobKoreaIt.domain.common.service;


public interface UserService {


}

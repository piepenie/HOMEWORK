package com.example.jobKoreaIt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JobKoreaItApplication {

	public static void main(String[] args) {
		SpringApplication.run(JobKoreaItApplication.class, args);
	}

}

package com.example.app.controller;


import com.example.app.domain.dto.MemberDTO;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.*;

import java.io.FileNotFoundException;

@Controller
@RequestMapping("/member")
@Slf4j
public class MemberController {

    @GetMapping("/join")
    public void memo_get() {
        log.info("GET /member/join..");
    }

    @PostMapping(value = "/join")
    public void memo_post(@ModelAttribute @Valid MemberDTO memberDto, BindingResult bindingResult, Model model) {
        log.info("POST /member/join..memberDto : " + memberDto + " bindingResult : " + bindingResult);

//        if(bindingResult.hasFieldErrors()) {
//            //log.info("ValidationCheck Error : "+bindingResult.getFieldError("id").getDefaultMessage());
//            for(FieldError error  :bindingResult.getFieldErrors()) {
//                log.info("ErrorField : " + error.getField() + " ErrorMsg : " + error.getDefaultMessage());
//                model.addAttribute(error.getField(),error.getDefaultMessage());
//            }
        }
    }












package com.example.app.domain.mapper;

import java.util.List;
import java.util.Map;

import com.example.app.domain.dto.MemberDTO;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.Update;

@Mapper
public interface MemberMapper {

	
	@SelectKey(statement="select max(id)+1 from tbl_member",keyProperty="id",before=false,resultType=int.class)
	@Insert("insert into tbl_member values(null,#{username},#{password},#{ROLE_USER})")
	public int Insert(MemberDTO memberDto);
	
	@Update("update tbl_member set username=#{username},password=#{password},ROLE_USER=#{ROLE_USER} where id=#{id}")
	public int Update(MemberDTO memberDto);
	
	@Delete("delete from tbl_member where id=#{id}")
	public int Delete(long id);
	
	@Select("select * from tbl_member where id=#{id}")
	public MemberDTO SelectAt(@Param("id") long aa);
	
	@Select("select * from tbl_member")
	public List<MemberDTO> SelectAll();
	
	@Results(id="MemoResultMap",value= {
			@Result(property="id",column="id"),
			@Result(property="username",column="username"),
			@Result(property="password",column="password"),
			@Result(property="ROLE_USER",column="ROLE_USER"),
	})
	
	@Select("select * from tbl_member")
	public List< Map<String,Object> > SelectAllResultMap();
	
	//MemberMapper.xml
	public int InsertXML(MemberDTO memberDto);
	public int UpdateXML(MemberDTO memberDto);
	public int DeleteXML(long id);
	public MemberDTO SelectAtXML(@Param("id") Long aa);
	public List<MemberDTO> SelectAllXML();
	public List< Map<String,Object> > SelectAllResultMapXML();
	
	//동적쿼리 적용함수
	public List< Map<String,Object> > SelectIf( Map<String,Object> map);
	public List< Map<String,Object> > SelectWhen( Map<String,Object> map );
	
	
}

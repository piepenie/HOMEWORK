package com.example.app.controller;


import com.example.app.domain.dto.UserDto;
import com.example.app.domain.service.UserService;
import jakarta.validation.Valid;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;

@Controller
@Slf4j
public class UserController {

    @Autowired
    private UserService userService;
    //회원가입 폼으로 이동
    @GetMapping("/user/joinForm")
    public void getJoinForm(){

    }
    //회원가입
    @PostMapping("/users")
    @ResponseBody
    public ResponseEntity<String> join(@Valid @RequestBody UserDto userDto, BindingResult bindingResult){
        System.out.println(userDto);
       return null;
    }


}

package com.example.app.domain.mapper;


import com.example.app.domain.dto.UserDto;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

@Mapper
public interface UserMapper {
    UserDto getUserById(@Param("id") String id); // 유저 Dto 에서 Id 값을 받아와서 그에 대한 정보를
    void insertUser(UserDto userDto);
    int updateUser(UserDto user);
    int deleteUserById(@Param("id") String id);
}

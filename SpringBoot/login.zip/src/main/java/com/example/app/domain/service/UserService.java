package com.example.app.domain.service;


import com.example.app.domain.dto.UserDto;
import com.example.app.domain.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    private UserMapper userMapper;

    public String userJoin(UserDto userDto) {
            UserDto result = UserDto.builder()
                    .id(userDto.getId())
                    .name(userDto.getName())
                    .phone(userDto.getPhone())
                    .email(userDto.getEmail())
                    .password(userDto.getPassword())
                    .role("ROLE_USER")
                    .build();
            userMapper.insertUser(result);
            return "SUCCESS";
    }

}

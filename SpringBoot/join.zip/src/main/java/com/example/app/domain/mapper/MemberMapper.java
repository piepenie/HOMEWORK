package com.example.app.domain.mapper;

import com.example.app.domain.dto.MemberDto;
import org.apache.ibatis.annotations.*;

import java.util.List;
import java.util.Map;

@Mapper
public interface MemberMapper {

    @SelectKey(statement = "select max(id)+1 from tbl_member", keyProperty = "id", before=false, resultType=int.class)
    @Insert("insert into tbl_member values(null,#{name},#{password},#{phone},#{email},'ROLE_USER'")
    public int Insert(MemberDto memberDto); // 여기서 왜 int 로 타입을 정하는지 + role 부분을 고정으로 해놓고 싶은데 어떻게?

    @Update("update tbl_member set #{name},#{password},#{phone},#{email},'ROLE_USER'")
    public int update(MemberDto memberDto);

    @Delete("delete from tbl_member where id=#{id}")
    public int Delete(int id);

    @Select("select * from tbl_member where id=#{id}")
    public MemberDto SelectAt(@Param("id") int aa); // 여기서 왜 int aa 를 사용하는것?

    @Select("select * from tbl_member")
    public List<MemberDto> SelectAll();

    @Results(id="MemberMapper", value ={ // ?
            @Result(property = "id", column = "id"),
            @Result(property = "name", column = "name"),
            @Result(property = "password", column = "password"),
            @Result(property = "phone", column = "phone"),
            @Result(property = "email", column = "email"),
            @Result(property = "role", column = "role"),
    })

    @Select("select * from tbl_member")
    public List<Map<String,Object>> SelectAllResultMap();

    //MamberMapper.xml // 이부분을 정확히 알고 싶음.
    public int InsertXML(MemberDto memberDto);
    public int UpdateXML(MemberDto memberDto);
    public int DeleteXML(int id);
    public MemberDto SelectAtXML(@Param("id") int aa);
    public List<MemberDto> SelectAllXML();
    public List< Map<String,Object> > SelectAllResultMapXML();

    //동적쿼리 적용함수
    public List< Map<String,Object> > SelectIf( Map<String,Object> map);
    public List< Map<String,Object> > SelectWhen( Map<String,Object> map );
}
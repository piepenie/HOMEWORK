package com.example.app.controller;


import com.example.app.domain.dto.MemberDto;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/user")
@Slf4j
public class MemberController {

    //회원가입 폼으로 이동
    @GetMapping("/joinForm")
    public void getJoinForm(){
        log.info("GET /user/joinForm.. ");

    }
    //회원가입( 사실상 값을 넣기만 해보는거 현재로써)
    @PostMapping(value = "/joinForm")
    public void postJoinForm(@ModelAttribute @Valid MemberDto memberDto, BindingResult bindingResult, Model model){
        log.info("POST /user/joinform.. ");

        if(bindingResult.hasFieldErrors()) {
            //log.info("ValidationCheck Error : "+bindingResult.getFieldError("id").getDefaultMessage());
            for(FieldError error  :bindingResult.getFieldErrors()) {
                log.info("ErrorField : " + error.getField() + " ErrorMsg : " + error.getDefaultMessage());
                model.addAttribute(error.getField(),error.getDefaultMessage());
            }
        }
    }



}

package com.example.app.controller;

import com.example.app.domain.dto.BoardDto;
import jakarta.validation.Valid;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Slf4j
@Data
@Controller
@RequestMapping("/Board")
public class BoardController {

    @GetMapping("/add")
    public void add(){
        log.info("GET /add");
    }

    @PostMapping(value = "/add")
    public String post_add(@ModelAttribute @Valid BoardDto boardDto, BindingResult bindingResult, Model model){
        System.out.println("boardDto = " + boardDto + ", bindingResult = " + bindingResult + ", model = " + model);




        return "redirect:/page/list";
    }

}

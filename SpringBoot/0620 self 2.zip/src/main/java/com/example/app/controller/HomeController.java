package com.example.app.controller;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
@Slf4j
public class HomeController {

    @GetMapping("/")
    public String index(Model model){
        log.info("GET / ");
        model.addAttribute("name","kimpani");
        model.addAttribute("img","image/img.jpg");
        return "index";
    }




}

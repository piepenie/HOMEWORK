package com.example.app.domain.mapper;

import com.example.app.domain.dto.MemberDto;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class MemberMapperTest {

    @Autowired
    private MemberMapper memberMapper;

//    @Test
//    void insert(){
//        assertNotNull(memberMapper);
//        memberMapper.Insert(new MemberDto(1,"123","123","123","123","ROLE_USER"));
//    }

    @Test
    void select(){
        MemberDto dto = memberMapper.getUserById("1010");
        System.out.println("dto : " + dto);



    }

}
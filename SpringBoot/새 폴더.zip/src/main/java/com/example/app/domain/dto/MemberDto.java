package com.example.app.domain.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MemberDto {
    @NotBlank(message = "아이디가 필요해요")
    private String id;

    @NotBlank(message = "이름이 필요해요")
    private String name;

    @NotBlank(message = "비밀번호가 필요해요")
    private String password;

    @NotBlank(message = "전화번호를 입력하세요")
    private String phone;

    @NotBlank(message = "이메일이 필요해요")
    private String email;

    private String role;
}

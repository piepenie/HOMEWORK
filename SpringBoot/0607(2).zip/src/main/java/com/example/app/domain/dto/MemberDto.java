package com.example.app.domain.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MemberDto {

    @NotBlank(message = "아이디가 필요해요")
    private String id;

    @NotBlank(message = "이름이 필요해요")
    private String name;

    @Size(min = 8, message = "비밀번호는 최소 8자리 이상이어야 합니다.")
    @NotBlank(message = "비밀번호가 필요해요")
    private String password;

    @NotBlank(message = "전화번호를 입력하세요")
    private String phone;

    @Email(message = "유효한 이메일 형식이 아닙니다.")
    @NotBlank(message = "이메일이 필요해요")
    private String email;

    private String role;
}

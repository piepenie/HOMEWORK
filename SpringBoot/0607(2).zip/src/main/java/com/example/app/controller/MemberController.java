package com.example.app.controller;


import com.example.app.domain.dto.MemberDto;
import com.example.app.domain.mapper.MemberMapper;
import com.example.app.domain.service.MemberService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/user")
@Slf4j
public class MemberController {

    @Autowired
    private MemberMapper memberMapper;

    @Autowired
    private MemberService memberService;

    //회원가입 폼으로 이동
    @GetMapping("/join")
    public void getJoinForm(){
        log.info("GET /user/join.. ");

    }
    //회원가입
    @PostMapping("/join")
    public String postJoinForm(@ModelAttribute @Valid MemberDto memberDto, BindingResult bindingResult, Model model) {
        log.info("POST /user/join..");

        // 유효성 검사 결과 확인
        if (bindingResult.hasFieldErrors()) {
            // 각 필드의 에러 메시지를 모델에 추가
            for (FieldError error : bindingResult.getFieldErrors()) {
                log.info("ErrorField : " + error.getField() + " ErrorMsg : " + error.getDefaultMessage());
                model.addAttribute(error.getField(), error.getDefaultMessage());
            }
            return "redirect:/user/join"; // 유효성 검사에 실패한 경우 회원가입창으로
        }

        // 유효성 검사가 통과된 경우의 로직
        memberService.join(memberDto);

        return "redirect:/"; // 성공 시 리다이렉트
    }

    // 로그인 폼으로 이동
    @GetMapping("/login")
    public void getLogin(){
        log.info("GET /user/login");
    }

    // 로그인
    @PostMapping("/login")
    public String postLogin(@ModelAttribute MemberDto memberDto, HttpSession session, Model model) {

        String regex = "^[a-zA-Z]{1}[a-zA-Z0-9_]{4,11}$";
        log.info("POST /user/login " + memberDto);


        if (memberDto.getId() == null|| memberDto.getId().isEmpty()){
            model.addAttribute("msg", "아이디가 없습니다");
            log.info("POST /user/login emptyId 아이디가 없습니다");
            return "user/login";
        }else if (memberDto.getPassword() == null|| memberDto.getId().isEmpty()){

            model.addAttribute("msg", "비밀번호가 일치하지 않습니다.");
            return "user/login";
        }

//        if (!memberDto.getId().equals(regex)){
//            model.addAttribute("msg","아이디 형식이 올바르지 않습니다.");
//            return "user/login";
//        }
        // 유효성 검사를 통과하면 로그인
        String loginResult = memberService.login(memberDto.getId(), memberDto.getPassword());

        if (loginResult == null) {
            model.addAttribute("msg", "아이디 또는 비밀번호가 잘못되었습니다.");
            System.out.println("로그인 실패");
            return "user/login";
        }

        session.setAttribute("id", memberDto.getId());
        System.out.println("로그인 성공");
        return "redirect:/";
    }

}

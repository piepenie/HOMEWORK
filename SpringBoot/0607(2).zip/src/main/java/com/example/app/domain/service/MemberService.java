package com.example.app.domain.service;

import com.example.app.domain.dto.MemberDto;
import com.example.app.domain.mapper.MemberMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class MemberService {
    @Autowired
    private MemberMapper memberMapper;

    @Autowired
    private PasswordEncoder passwordEncoder;

    // 회원 가입 서비스
    public void join(MemberDto memberDto) {
        String encodedPassword = passwordEncoder.encode(memberDto.getPassword()); // 멤버 dto 에 넣어질 password 값을 암호화해서 encodedPassword 이라고함
        memberDto.setPassword(encodedPassword); // encodedPassword 값을

        memberMapper.InsertMember(memberDto);
    }

    public String login(String id, String password){
        MemberDto memberDto = memberMapper.getUserById(id);
        if (memberDto != null && passwordEncoder.matches(password, memberDto.getPassword())) {
            return memberDto.getId();
        }
        return null;
    }


}

package com.example.app.domain.service;

import com.example.app.domain.dto.MemberDto;
import com.example.app.domain.mapper.MemberMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MemberService {
    @Autowired
    private static MemberMapper memberMapper;

    public static String login(String id, String password) {
        MemberDto memberDto = memberMapper.getUserById(id);
        if (memberDto.getPassword().equals(password))
            return memberDto.getId();
        return null;
    }

}

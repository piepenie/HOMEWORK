package com.example.app.domain.mapper;

import com.example.app.domain.dto.MemberDto;
import org.apache.ibatis.annotations.*;

import java.util.List;
import java.util.Map;

@Mapper
public interface MemberMapper {
    MemberDto getUserById(@Param("id") String id);

    public int InsertMember(MemberDto memberDto);

    public int UpdateMember(MemberDto memberDto);

    public int DeleteMember(String id);

    public MemberDto SelectAt(String id);

}